package com.example.recyclerview_practice

class Name (val name:String, val photo: String)